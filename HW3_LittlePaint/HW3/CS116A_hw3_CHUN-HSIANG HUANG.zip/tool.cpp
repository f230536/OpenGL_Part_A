#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <GL/glut.h>
#include "draw.h"
#include "interaction.h"

void Translate(float &px, float &py, float tx, float ty) {
  px += tx;
  py += ty;
}
