
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <GL/glut.h>
#include "draw.h"
#include "interaction.h"
//#include "Hexagon.h"
#define Ysize 3
#define Xsize 2
#define MAX 100
class save{
public:
	int x;
	int y;
	scrPt type;
};

////1///////////////////////////
void sideGlutDisplay( void );
void Control();
void defaults();
scrPt check(int x, int y);
void fresh(int x , int y);
void saving(int x, int y);
////////////////////////////////

int side_window;
bool first = true;
range controlP[Xsize][Ysize];
range currrent;
scrPt pick,  newPt;;
save proj[MAX];
int total=0;
int state1,button1;

void redraw_func(int id) {

    glutSetWindow(side_window);  
	glutPostRedisplay();
}

/***************************************** myGlutIdle() ***********/

void myGlutIdle( void )
{

	
}


void myGlutDisplay( void )
{
	
	glClearColor(1,1,1,0);
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0,600,0.0,400);
			// left, right, bottom, top
	glViewport(0,0,600,400);
			// startx, starty, xsize, ysize
			// coordinates begin from lower left corner of window		
    glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();	
	Control();



	glutSwapBuffers(); 

}
/*******Control*************/
void Control(){
	//set table
	drawTable();
	//set the button position	
	for( int y = 0; y< 3 ; ++ y){
		for (int x=0;x< 2; ++ x){
		controlP[x][y].pt1.x =400+ 100* x;
		controlP[x][y].pt1.y =133*y;
		controlP[x][y].pt2.x =400+ 100* (x+1);
		controlP[x][y].pt2.y =133*y;
		controlP[x][y].pt3.x =400+ 100*(x+1);
		controlP[x][y].pt3.y =133*(y+1);
		controlP[x][y].pt4.x =400+ 100*x;
		controlP[x][y].pt4.y =133*(y+1);
		}
	}
	defaults();
}
/***************************************/
void defaults(){
	//draw circle
		int Xc = 450;
		int Yc = 333;
		setCicrle(Xc, Yc);
	//draw Hexagon
		Xc = 450;
		Yc = 200;
		setHexagon(Xc,Yc);
	//draw Square
		Xc = 450;
		Yc = 66;
		setSquare(Xc ,Yc);
	//draw Scale
		Xc = 550;
		Yc = 333;
		setScale(Xc,Yc);
	//draw translate
		Xc = 550;
		Yc = 200;
		setTrans(Xc,Yc);
	//draw Rotate
		Xc = 550;
		Yc = 66 ;
		setRotate(Xc, Yc);
}

/***************************************** myGlutMouse() **********/

void myGlutMouse(int button, int state, int x, int y )
{
	state1 = state;
	button1= button;
	glClearColor(1,1,1,0);
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	
	glReadBuffer(GL_BACK);
	if(button ==GLUT_RIGHT_BUTTON ){
		 y = 400-y;
		 if(x > 400 ){
	  
				 
					pick = check(x,y);
					if(pick.x >= 0 && pick.y >= 0){
					if(first){
						currrent = controlP[pick.x][pick.y];
						highlight( currrent,first);
						first = false;
		
					}
					else		
						fresh(x,y);

		
					}
		
				glutSwapBuffers();
		 }

	
	}
	else if(button ==GLUT_LEFT_BUTTON){
		  y = 400-y;
		  if(!first){
			saving(x,y);
			fresh( x ,  y);	  
			glutSwapBuffers();
		  }
	}
}
void fresh(int x , int y){
	currrent = controlP[pick.x][pick.y];			
    highlight( currrent,true);
	defaults();
	if(total !=0)
		for(int i =0; i<total; ++i)
			switchs(proj[i].x, proj[i].y,proj[i].type);
}


void saving(int x, int y){
	 bool repeat = false;
	
//interaction 
if(pick.x ==1){
	for(int i = 0; i<MAX;++i){
		if(proj[i].x == x && proj[i].y==y){
		 proj[i].x = x;
		 proj[i].y = y;
		 proj[i].type = pick;
		 repeat = true;
		 break;
		}
	}
}
// draw
else if(pick.x ==0){
	if (!repeat){
	 proj[total].x = x;
	 proj[total].y = y;
	 proj[total].type = pick;
	 ++total;
	 repeat = false;
	}
}

}
		

/*******************************************************/
scrPt check(int x, int y){
	scrPt p;
	
	for (int i = 0; i< Ysize ; ++i ){
		for (int n = 0; n< Xsize ; ++n ){
			if ( 400 <x && x < controlP[n][i].pt3.x)
				if (y <controlP[n][i].pt3.y){
					p.x= n;
					p.y= i;
					return p;
				}
			
		}
	
	}
	p.x = -1;
	p.y = -1;
	return p;

}

/***************************************** myGlutMotion() **********/

void myGlutMotion(int x, int y )
{
	if(state1 ==GLUT_DOWN ){
		y = 400-y;
		newPt.x = x;
		newPt.y = y;
		  if(!first){
			saving(x,y);
			fresh( x ,  y);	  
			glutSwapBuffers();
		  }
	}
}

/**************************************** myGlutReshape() *************/

void myGlutReshape( int x, int y )
{

  glutPostRedisplay();
}

/********************* myGlutKeyboard() **********/

void myGlutKeyboard(unsigned char Key, int x, int y)
{
  switch(Key)
  {
  case 27: 
  case 'q':
    exit(0);
    break;
  };
  
  glutPostRedisplay();
}





/**************************************** main() ********************/

int main(int argc, char* argv[])
{

	glutInitDisplayMode( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH );
  
	side_window = glutCreateWindow( "HW3" );
	glutPositionWindow( 10, 30 );
	glutReshapeWindow( 600 , 400 );

	glutDisplayFunc( myGlutDisplay );
	glutReshapeFunc( myGlutReshape );  
	glutKeyboardFunc( myGlutKeyboard );
	glutMotionFunc( myGlutMotion );
	glutMouseFunc( myGlutMouse );


	glutMainLoop();

	return 0;

}

