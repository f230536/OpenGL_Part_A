void Translate(float &px, float &py, float tx, float ty);
